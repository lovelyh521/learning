package com.xiejieyi.security.ssoserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsoserverApplication.class, args);
	}
}
